/*****************************************************************/
/*         Trabalho pratico 1 | PROG2 | MIEEC | 2017/18          */
/*****************************************************************/
/*                    FUNCOES A IMPLEMENTAR                      */
/*****************************************************************/

#include "cidades.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

vetor* cidades_load(const char *nomef)
{
  return NULL;
}

int cidades_save(const vetor *vec, const char *nomef)
{
  return -1;
}

int cidades_peek(const char *nomef, const char *nomecidade, cidade *resultado)
{
	return -1;
}

int cidades_poke(const char *nomef, const char *nomecidade, cidade nova)
{
  return -1;
}

int cidades_resort(vetor *vec, char criterio)
{
  return -1;
}

char** cidades_similar (vetor *vec, const char *nomecidade, int deltapop, int *nsimilares)
{
  return NULL;
}
